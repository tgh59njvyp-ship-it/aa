import "dotenv/config";
import { createApp } from "../server/_core/app";

// Vercel は /api 配下の各ファイルを個別のサーバーレス関数として扱う。
// ここでは Express アプリをそのまま default export しており、Vercel の
// Node.js ランタイムが (req, res) を渡して呼び出す形にそのまま対応できる。
// フロントエンド(静的ファイル)は vite build の出力(dist/public)を
// Vercel が直接配信し、/api/* と /manus-storage/* だけがこの関数に
// ルーティングされる(vercel.json の rewrites を参照)。
const app = createApp();

export default app;
