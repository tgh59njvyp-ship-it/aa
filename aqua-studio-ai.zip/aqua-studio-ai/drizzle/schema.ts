import { index, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["draft", "building", "ready", "published", "error"]).default("draft").notNull(),
  buildMode: mysqlEnum("buildMode", ["prototype", "production"]).default("prototype").notNull(),
  progress: int("progress").default(0).notNull(),
  previewUrl: text("previewUrl"),
  filesSnapshot: text("filesSnapshot"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("projects_user_updated_idx").on(table.userId, table.updatedAt)]);

export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId").notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("conversations_project_updated_idx").on(table.projectId, table.updatedAt)]);

export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  attachments: text("attachments"),
  buildStage: varchar("buildStage", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("messages_conversation_created_idx").on(table.conversationId, table.createdAt)]);

export const studioSettings = mysqlTable("studioSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  geminiApiKeyEncrypted: text("geminiApiKeyEncrypted"),
  selectedModel: varchar("selectedModel", { length: 120 }).default("gemini-2.5-flash").notNull(),
  imageModel: varchar("imageModel", { length: 120 }),
  githubTokenEncrypted: text("githubTokenEncrypted"),
  githubLogin: varchar("githubLogin", { length: 120 }),
  cloudProvider: varchar("cloudProvider", { length: 80 }),
  cloudTokenEncrypted: text("cloudTokenEncrypted"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const mediaAssets = mysqlTable("mediaAssets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId").notNull(),
  type: mysqlEnum("type", ["generated_image", "reference_image", "audio", "document"]).notNull(),
  name: varchar("name", { length: 220 }).notNull(),
  url: text("url").notNull(),
  storageKey: text("storageKey"),
  prompt: text("prompt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("media_project_created_idx").on(table.projectId, table.createdAt)]);

export const deployments = mysqlTable("deployments", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  provider: varchar("provider", { length: 80 }).notNull(),
  serverPreset: varchar("serverPreset", { length: 80 }).notNull(),
  region: varchar("region", { length: 80 }).notNull(),
  buildCommand: varchar("buildCommand", { length: 255 }).notNull(),
  environmentMask: text("environmentMask"),
  status: mysqlEnum("status", ["idle", "queued", "building", "live", "failed"]).default("idle").notNull(),
  publicUrl: text("publicUrl"),
  logs: text("logs"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("deployments_project_updated_idx").on(table.projectId, table.updatedAt)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
