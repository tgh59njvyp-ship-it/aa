CREATE TABLE `conversations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`projectId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `conversations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `deployments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`provider` varchar(80) NOT NULL,
	`serverPreset` varchar(80) NOT NULL,
	`region` varchar(80) NOT NULL,
	`buildCommand` varchar(255) NOT NULL,
	`environmentMask` text,
	`status` enum('idle','queued','building','live','failed') NOT NULL DEFAULT 'idle',
	`publicUrl` text,
	`logs` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `deployments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `mediaAssets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`projectId` int NOT NULL,
	`type` enum('generated_image','reference_image','audio','document') NOT NULL,
	`name` varchar(220) NOT NULL,
	`url` text NOT NULL,
	`storageKey` text,
	`prompt` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `mediaAssets_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`conversationId` int NOT NULL,
	`role` enum('user','assistant','system') NOT NULL,
	`content` text NOT NULL,
	`attachments` text,
	`buildStage` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(160) NOT NULL,
	`description` text,
	`status` enum('draft','building','ready','published','error') NOT NULL DEFAULT 'draft',
	`buildMode` enum('prototype','production') NOT NULL DEFAULT 'prototype',
	`progress` int NOT NULL DEFAULT 0,
	`previewUrl` text,
	`filesSnapshot` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `studioSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`geminiApiKeyEncrypted` text,
	`selectedModel` varchar(120) NOT NULL DEFAULT 'gemini-2.5-flash',
	`imageModel` varchar(120),
	`githubTokenEncrypted` text,
	`githubLogin` varchar(120),
	`cloudProvider` varchar(80),
	`cloudTokenEncrypted` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `studioSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `studioSettings_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE INDEX `conversations_project_updated_idx` ON `conversations` (`projectId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `deployments_project_updated_idx` ON `deployments` (`projectId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `media_project_created_idx` ON `mediaAssets` (`projectId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `messages_conversation_created_idx` ON `messages` (`conversationId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `projects_user_updated_idx` ON `projects` (`userId`,`updatedAt`);