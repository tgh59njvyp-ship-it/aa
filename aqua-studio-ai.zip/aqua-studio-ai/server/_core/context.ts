import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import * as db from "../db";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

// --- ログイン機能を無効化 ---
// 元々は sdk.authenticateRequest() で OAuth セッションを検証していたが、
// ログイン画面を経由せずアプリに入れるよう、固定のローカルユーザーを
// 常に返すようにしている。DB が使える場合はそのユーザーを自動作成/取得し、
// 使えない場合でもメモリ上のダミーユーザーでフォールバックする。
const LOCAL_OPEN_ID = "local-user";

function buildFallbackUser(): User {
  const now = new Date();
  return {
    id: 1,
    openId: LOCAL_OPEN_ID,
    name: "Local User",
    email: null,
    loginMethod: null,
    role: "admin",
    createdAt: now,
    updatedAt: now,
    lastSignedIn: now,
  } as User;
}

async function getLocalUser(): Promise<User> {
  try {
    let user = await db.getUserByOpenId(LOCAL_OPEN_ID);
    if (!user) {
      await db.upsertUser({
        openId: LOCAL_OPEN_ID,
        name: "Local User",
        email: null,
        loginMethod: "local",
        lastSignedIn: new Date(),
        role: "admin",
      });
      user = await db.getUserByOpenId(LOCAL_OPEN_ID);
    }
    return (user as User) ?? buildFallbackUser();
  } catch (error) {
    console.warn("[Auth] Falling back to in-memory local user:", error);
    return buildFallbackUser();
  }
}

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  const user = await getLocalUser();

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
