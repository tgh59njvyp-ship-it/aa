import { afterEach, describe, expect, it } from "vitest";
import { decryptSecret, encryptSecret } from "./studioCrypto";

const originalSecret = process.env.JWT_SECRET;

afterEach(() => {
  process.env.JWT_SECRET = originalSecret;
});

describe("studio secret encryption", () => {
  it("round-trips a secret without retaining it in plaintext", () => {
    process.env.JWT_SECRET = "unit-test-encryption-key";
    const encrypted = encryptSecret("AIza-example-key");
    expect(encrypted).not.toContain("AIza-example-key");
    expect(decryptSecret(encrypted)).toBe("AIza-example-key");
  });
});
