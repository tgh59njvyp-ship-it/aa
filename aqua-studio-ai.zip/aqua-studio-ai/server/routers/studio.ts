import { TRPCError } from "@trpc/server";
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { conversations, deployments, mediaAssets, messages, projects, studioSettings } from "../../drizzle/schema";
import { getDb } from "../db";
import { decryptSecret, encryptSecret } from "../studioCrypto";
import { storagePut } from "../storage";
import { protectedProcedure, router } from "../_core/trpc";

const modelsFallback = ["gemini-3.7-flash", "gemini-3.5-flash", "gemini-3.0-flash", "gemini-2.5-flash", "gemini-2.0-flash"];
const attachmentSchema = z.object({ name: z.string().max(180), url: z.string().max(10_000_000), type: z.string().max(80) });

async function requireDb() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "データベースに接続できません。" });
  return db;
}

async function ownedProject(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, userId: number, projectId: number) {
  const [project] = await db.select().from(projects).where(and(eq(projects.id, projectId), eq(projects.userId, userId))).limit(1);
  if (!project) throw new TRPCError({ code: "NOT_FOUND", message: "プロジェクトが見つかりません。" });
  return project;
}

async function settingsFor(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, userId: number) {
  const [settings] = await db.select().from(studioSettings).where(eq(studioSettings.userId, userId)).limit(1);
  return settings;
}

function safeSettings(settings: Awaited<ReturnType<typeof settingsFor>>) {
  return {
    configured: Boolean(settings?.geminiApiKeyEncrypted),
    selectedModel: settings?.selectedModel ?? "gemini-2.5-flash",
    imageModel: settings?.imageModel ?? "",
    githubConnected: Boolean(settings?.githubTokenEncrypted),
    githubLogin: settings?.githubLogin ?? null,
    cloudProvider: settings?.cloudProvider ?? null,
    cloudConnected: Boolean(settings?.cloudTokenEncrypted),
    updatedAt: settings?.updatedAt ?? null,
  };
}

async function geminiJson(apiKey: string, path: string, init?: RequestInit) {
  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/${path}${path.includes("?") ? "&" : "?"}key=${encodeURIComponent(apiKey)}`, init);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new TRPCError({ code: "BAD_REQUEST", message: body?.error?.message ?? "Gemini APIへの接続に失敗しました。" });
  }
  return body;
}

async function geminiInteraction(apiKey: string, body: Record<string, unknown>) {
  const response = await fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new TRPCError({ code: "BAD_REQUEST", message: data?.error?.message ?? "Gemini APIへの接続に失敗しました。" });
  return data as { output_text?: string; output_image?: { data?: string; mime_type?: string }; steps?: Array<{ content?: Array<{ type?: string; text?: string }> }> };
}

function dataUrlToInteractionInput(attachment: { name: string; url: string; type: string }) {
  const match = attachment.url.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return null;
  const [, mimeType, data] = match;
  if (attachment.type === "reference_image") return { type: "image", data, mime_type: mimeType };
  if (attachment.type === "audio") return { type: "audio", data, mime_type: mimeType };
  if (attachment.type === "document") return { type: "file", data, mime_type: mimeType };
  return null;
}

export const studioRouter = router({
  projects: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const db = await requireDb();
      return db.select().from(projects).where(eq(projects.userId, ctx.user.id)).orderBy(desc(projects.updatedAt));
    }),
    create: protectedProcedure.input(z.object({ name: z.string().min(1).max(160), description: z.string().max(1000).optional(), buildMode: z.enum(["prototype", "production"]).default("prototype") })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const result = await db.insert(projects).values({ userId: ctx.user.id, name: input.name, description: input.description ?? null, buildMode: input.buildMode });
      const [project] = await db.select().from(projects).where(eq(projects.id, Number(result[0].insertId))).limit(1);
      return project;
    }),
    update: protectedProcedure.input(z.object({ projectId: z.number().int(), name: z.string().min(1).max(160).optional(), buildMode: z.enum(["prototype", "production"]).optional() })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      const changes = {
        ...(input.name ? { name: input.name } : {}),
        ...(input.buildMode ? { buildMode: input.buildMode } : {}),
      };
      await db.update(projects).set(changes).where(eq(projects.id, input.projectId));
      return { success: true };
    }),
  }),
  conversations: router({
    list: protectedProcedure.input(z.object({ projectId: z.number().int() })).query(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      return db.select().from(conversations).where(and(eq(conversations.projectId, input.projectId), eq(conversations.userId, ctx.user.id))).orderBy(desc(conversations.updatedAt));
    }),
    create: protectedProcedure.input(z.object({ projectId: z.number().int(), title: z.string().min(1).max(180).default("新しい制作チャット") })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      const result = await db.insert(conversations).values({ projectId: input.projectId, userId: ctx.user.id, title: input.title });
      const [conversation] = await db.select().from(conversations).where(eq(conversations.id, Number(result[0].insertId))).limit(1);
      return conversation;
    }),
    rename: protectedProcedure.input(z.object({ conversationId: z.number().int(), title: z.string().min(1).max(180) })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const [conversation] = await db.select().from(conversations).where(and(eq(conversations.id, input.conversationId), eq(conversations.userId, ctx.user.id))).limit(1);
      if (!conversation) throw new TRPCError({ code: "NOT_FOUND", message: "会話が見つかりません。" });
      await db.update(conversations).set({ title: input.title }).where(eq(conversations.id, input.conversationId));
      return { success: true };
    }),
    remove: protectedProcedure.input(z.object({ conversationId: z.number().int() })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const [conversation] = await db.select().from(conversations).where(and(eq(conversations.id, input.conversationId), eq(conversations.userId, ctx.user.id))).limit(1);
      if (!conversation) throw new TRPCError({ code: "NOT_FOUND", message: "会話が見つかりません。" });
      await db.delete(messages).where(eq(messages.conversationId, input.conversationId));
      await db.delete(conversations).where(eq(conversations.id, input.conversationId));
      return { success: true };
    }),
    messages: protectedProcedure.input(z.object({ conversationId: z.number().int() })).query(async ({ ctx, input }) => {
      const db = await requireDb();
      const [conversation] = await db.select().from(conversations).where(and(eq(conversations.id, input.conversationId), eq(conversations.userId, ctx.user.id))).limit(1);
      if (!conversation) throw new TRPCError({ code: "NOT_FOUND", message: "会話が見つかりません。" });
      return db.select().from(messages).where(eq(messages.conversationId, input.conversationId)).orderBy(messages.createdAt);
    }),
  }),
  settings: router({
    get: protectedProcedure.query(async ({ ctx }) => safeSettings(await settingsFor(await requireDb(), ctx.user.id))),
    saveGemini: protectedProcedure.input(z.object({ apiKey: z.string().min(12).max(500).optional(), selectedModel: z.string().min(3).max(120), imageModel: z.string().max(120).optional() })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const existing = await settingsFor(db, ctx.user.id);
      const values = { selectedModel: input.selectedModel, imageModel: input.imageModel || null, ...(input.apiKey ? { geminiApiKeyEncrypted: encryptSecret(input.apiKey) } : {}) };
      if (existing) await db.update(studioSettings).set(values).where(eq(studioSettings.userId, ctx.user.id));
      else await db.insert(studioSettings).values({ userId: ctx.user.id, ...values });
      return safeSettings(await settingsFor(db, ctx.user.id));
    }),
    models: protectedProcedure.query(async ({ ctx }) => {
      const db = await requireDb();
      const settings = await settingsFor(db, ctx.user.id);
      if (!settings?.geminiApiKeyEncrypted) return modelsFallback.map(id => ({ id, displayName: id, supportedGenerationMethods: ["generateContent"] }));
      const apiKey = decryptSecret(settings.geminiApiKeyEncrypted);
      const data = await geminiJson(apiKey, "models");
      return (data.models ?? []).filter((model: { name?: string; supportedGenerationMethods?: string[] }) => {
        const id = model.name?.replace("models/", "") ?? "";
        const version = Number(id.match(/gemini-(\d+(?:\.\d+)?)/)?.[1] ?? 99);
        return id.includes("gemini") && version <= 3.7 && model.supportedGenerationMethods?.includes("generateContent");
      }).map((model: { name: string; displayName?: string; supportedGenerationMethods?: string[] }) => ({ id: model.name.replace("models/", ""), displayName: model.displayName ?? model.name, supportedGenerationMethods: model.supportedGenerationMethods ?? [] }));
    }),
  }),
  builder: router({
    build: protectedProcedure.input(z.object({ projectId: z.number().int(), conversationId: z.number().int(), prompt: z.string().min(2).max(12000), attachments: z.array(attachmentSchema).max(8).default([]) })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const project = await ownedProject(db, ctx.user.id, input.projectId);
      const [conversation] = await db.select().from(conversations).where(and(eq(conversations.id, input.conversationId), eq(conversations.projectId, input.projectId), eq(conversations.userId, ctx.user.id))).limit(1);
      if (!conversation) throw new TRPCError({ code: "NOT_FOUND", message: "制作チャットが見つかりません。" });
      const settings = await settingsFor(db, ctx.user.id);
      if (!settings?.geminiApiKeyEncrypted) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Gemini APIキーを設定してからビルドを開始してください。" });
      await db.update(projects).set({ status: "building", progress: 18 }).where(eq(projects.id, project.id));
      await db.insert(messages).values({ conversationId: conversation.id, role: "user", content: input.prompt, attachments: JSON.stringify(input.attachments), buildStage: "brief" });
      const context = `あなたはAqua StudioのWeb制作専門AIです。ユーザーの意図を、実装可能なWebサイト仕様・画面構成・コンポーネント・技術構成へ変換します。プロジェクト名: ${project.name}。ビルドモード: ${project.buildMode}。添付資料: ${input.attachments.map(item => item.name).join(", ") || "なし"}。必ずJSONのみを返してください。形式は {"overview":"日本語の制作概要","files":[{"path":"src/App.tsx","language":"tsx","content":"ファイル全文"},{"path":"src/styles.css","language":"css","content":"ファイル全文"},{"path":"package.json","language":"json","content":"ファイル全文"}],"previewHtml":"スクリプトを含まない安全なHTML全文"} です。filesは少なくとも3件、最大5件です。アクセシビリティとモバイル対応をコードに含め、previewHtmlには外部スクリプト・フォーム送信・iframeを含めません。`;
      try {
        const mediaInput = input.attachments.map(dataUrlToInteractionInput).filter((item): item is NonNullable<typeof item> => Boolean(item));
        const data = await geminiInteraction(decryptSecret(settings.geminiApiKeyEncrypted), {
          model: settings.selectedModel,
          system_instruction: context,
          input: [{ type: "text", text: input.prompt }, ...mediaInput],
          generation_config: { temperature: 0.55, thinking_level: "low" },
        });
        const fallbackContent = data.steps?.flatMap(step => step.content ?? []).filter(item => item.type === "text").map(item => item.text ?? "").join("");
        const rawContent = data.output_text?.trim() || fallbackContent?.trim() || "";
        const normalized = rawContent.replace(/^```json\s*/i, "").replace(/\s*```$/, "");
        let generated: { overview?: string; files?: Array<{ path?: string; language?: string; content?: string }>; previewHtml?: string } = {};
        try { generated = JSON.parse(normalized); } catch { /* A readable response is still saved when a model ignores the JSON contract. */ }
        const generatedFiles = (generated.files ?? []).filter(file => file.path && file.content).slice(0, 5).map(file => ({ path: file.path!, language: file.language || "text", content: file.content! }));
        const content = generated.overview?.trim() || rawContent || "ビルド仕様を生成できませんでした。もう一度お試しください。";
        await db.insert(messages).values({ conversationId: conversation.id, role: "assistant", content, buildStage: "complete" });
        await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, conversation.id));
        await db.update(projects).set({ status: "ready", progress: 100, filesSnapshot: JSON.stringify({ files: generatedFiles, previewHtml: generated.previewHtml?.slice(0, 200_000) || "" }) }).where(eq(projects.id, project.id));
        return { content, stages: [{ label: "要件を解析", state: "complete" }, { label: "画面を構成", state: "complete" }, { label: "制作仕様を生成", state: "complete" }] };
      } catch (error) {
        await db.update(projects).set({ status: "error", progress: 0 }).where(eq(projects.id, project.id));
        throw error;
      }
    }),
  }),
  deployment: router({
    list: protectedProcedure.input(z.object({ projectId: z.number().int() })).query(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      return db.select().from(deployments).where(eq(deployments.projectId, input.projectId)).orderBy(desc(deployments.updatedAt));
    }),
    save: protectedProcedure.input(z.object({ projectId: z.number().int(), provider: z.string().min(2).max(80), serverPreset: z.string().min(2).max(80), region: z.string().min(2).max(80), buildCommand: z.string().min(2).max(255), environmentMask: z.string().max(2000).optional() })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      const result = await db.insert(deployments).values({ ...input, environmentMask: input.environmentMask ?? null, logs: "構成を保存しました。デプロイ連携を設定すると、ここに実行ログが表示されます。" });
      return { id: Number(result[0].insertId), success: true };
    }),
    requestLaunch: protectedProcedure.input(z.object({ projectId: z.number().int() })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      const settings = await settingsFor(db, ctx.user.id);
      if (!settings?.githubTokenEncrypted || !settings.cloudTokenEncrypted || !settings.cloudProvider) {
        throw new TRPCError({ code: "PRECONDITION_FAILED", message: "GitHubとクラウドを接続してから公開リクエストを開始してください。" });
      }
      const [existing] = await db.select().from(deployments).where(eq(deployments.projectId, input.projectId)).orderBy(desc(deployments.updatedAt)).limit(1);
      if (existing) {
        await db.update(deployments).set({ status: "queued", logs: `${existing.logs ?? ""}\n公開リクエストを待機列に追加しました。接続先クラウドのデプロイ完了後に公開URLを登録してください。` }).where(eq(deployments.id, existing.id));
        return { id: existing.id, status: "queued" as const };
      }
      const result = await db.insert(deployments).values({ projectId: input.projectId, provider: settings.cloudProvider, serverPreset: "Node.js Production", region: "Asia Pacific", buildCommand: "pnpm build", status: "queued", logs: "公開リクエストを待機列に追加しました。接続先クラウドのデプロイ完了後に公開URLを登録してください。" });
      return { id: Number(result[0].insertId), status: "queued" as const };
    }),
    setPublicUrl: protectedProcedure.input(z.object({ deploymentId: z.number().int(), publicUrl: z.string().url().max(2048) })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const [deployment] = await db.select({ deployment: deployments, project: projects }).from(deployments).innerJoin(projects, eq(deployments.projectId, projects.id)).where(and(eq(deployments.id, input.deploymentId), eq(projects.userId, ctx.user.id))).limit(1);
      if (!deployment) throw new TRPCError({ code: "NOT_FOUND", message: "デプロイ構成が見つかりません。" });
      await db.update(deployments).set({ publicUrl: input.publicUrl, status: "live", logs: `${deployment.deployment.logs ?? ""}\n公開URLを確認しました: ${input.publicUrl}` }).where(eq(deployments.id, input.deploymentId));
      await db.update(projects).set({ status: "published", previewUrl: input.publicUrl }).where(eq(projects.id, deployment.project.id));
      return { success: true };
    }),
  }),
  connections: router({
    saveGithub: protectedProcedure.input(z.object({ token: z.string().min(12).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const response = await fetch("https://api.github.com/user", { headers: { Authorization: `Bearer ${input.token}`, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28" } });
      const profile = await response.json().catch(() => ({}));
      if (!response.ok || !profile.login) throw new TRPCError({ code: "BAD_REQUEST", message: "GitHubトークンを確認できません。リポジトリ権限を確認してください。" });
      const values = { githubTokenEncrypted: encryptSecret(input.token), githubLogin: String(profile.login) };
      const existing = await settingsFor(db, ctx.user.id);
      if (existing) await db.update(studioSettings).set(values).where(eq(studioSettings.userId, ctx.user.id));
      else await db.insert(studioSettings).values({ userId: ctx.user.id, ...values });
      return { login: profile.login };
    }),
    saveCloud: protectedProcedure.input(z.object({ provider: z.enum(["Cloudflare", "Vercel", "Netlify", "AWS", "Google Cloud"]), token: z.string().min(8).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      const values = { cloudProvider: input.provider, cloudTokenEncrypted: encryptSecret(input.token) };
      const existing = await settingsFor(db, ctx.user.id);
      if (existing) await db.update(studioSettings).set(values).where(eq(studioSettings.userId, ctx.user.id));
      else await db.insert(studioSettings).values({ userId: ctx.user.id, ...values });
      return { provider: input.provider, connected: true };
    }),
  }),
  media: router({
    list: protectedProcedure.input(z.object({ projectId: z.number().int() })).query(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      return db.select().from(mediaAssets).where(and(eq(mediaAssets.projectId, input.projectId), eq(mediaAssets.userId, ctx.user.id))).orderBy(desc(mediaAssets.createdAt));
    }),
    upload: protectedProcedure.input(z.object({ projectId: z.number().int(), name: z.string().min(1).max(220), mimeType: z.string().min(3).max(100), dataUrl: z.string().min(30).max(10_000_000), type: z.enum(["reference_image", "audio", "document"]) })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      const base64 = input.dataUrl.split(",")[1];
      if (!base64) throw new TRPCError({ code: "BAD_REQUEST", message: "ファイル形式を読み取れません。" });
      const bytes = Buffer.from(base64, "base64");
      const safeName = input.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const { key, url } = await storagePut(`studio/${ctx.user.id}/${input.projectId}/${Date.now()}-${safeName}`, bytes, input.mimeType);
      const result = await db.insert(mediaAssets).values({ userId: ctx.user.id, projectId: input.projectId, type: input.type, name: input.name, url, storageKey: key });
      return { id: Number(result[0].insertId), url, name: input.name };
    }),
    generateImage: protectedProcedure.input(z.object({ projectId: z.number().int(), prompt: z.string().min(5).max(2000) })).mutation(async ({ ctx, input }) => {
      const db = await requireDb();
      await ownedProject(db, ctx.user.id, input.projectId);
      const settings = await settingsFor(db, ctx.user.id);
      if (!settings?.geminiApiKeyEncrypted) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "Gemini APIキーを設定してから画像を生成してください。" });
      const data = await geminiInteraction(decryptSecret(settings.geminiApiKeyEncrypted), {
        model: settings.imageModel || "gemini-3.1-flash-image",
        input: [{ type: "text", text: `Webサイトのための洗練されたビジュアル素材。${input.prompt}` }],
        response_format: { type: "image", mime_type: "image/png", aspect_ratio: "16:9", image_size: "1K" },
      });
      const imageData = data.output_image?.data;
      if (!imageData) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Geminiから画像データを取得できませんでした。" });
      const { key, url: imageUrl } = await storagePut(`studio/${ctx.user.id}/${input.projectId}/generated-${Date.now()}.png`, Buffer.from(imageData, "base64"), data.output_image?.mime_type || "image/png");
      const insert = await db.insert(mediaAssets).values({ userId: ctx.user.id, projectId: input.projectId, type: "generated_image", name: "Gemini生成ビジュアル", url: imageUrl, storageKey: key, prompt: input.prompt });
      return { id: Number(insert[0].insertId), url: imageUrl, name: "Gemini生成ビジュアル" };
    }),
  }),
});
